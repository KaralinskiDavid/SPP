﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using System.IO;
using TracerLib;

namespace ConsoleApp9
{
    class XmlSerializator : Serializator
    {
        public XmlSerializator()
        {
        }

        public override string Serialize(TraceResult tr)
        {
            XmlSerializer formatter = new XmlSerializer(typeof(TraceResult));
            string result;
            using(StringWriter writer = new StringWriter())
            {
                formatter.Serialize(writer, tr);
                result = writer.ToString();
            }
            //using (FileStream fs = new FileStream(FilePath, FileMode.OpenOrCreate))
            //{
            //    formatter.Serialize(fs, tr);
            //}
            return result;

        }
    }
}
