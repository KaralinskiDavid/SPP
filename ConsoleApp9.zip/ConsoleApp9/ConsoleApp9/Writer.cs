﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace ConsoleApp9
{
    public abstract class Writer
    {
        public abstract void Write(string Serialized);
    }
}
