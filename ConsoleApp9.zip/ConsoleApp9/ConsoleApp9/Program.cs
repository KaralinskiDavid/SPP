﻿using System;
using System.Xml.Serialization;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using System.Threading;
using System.IO;
using TracerLib;

namespace ConsoleApp9
{
    class Program
    {
        static void Main(string[] args)
        {
            ITracer it = new Tracer();
            Foo f1 = new Foo(it);
            Bar1 b1 = new Bar1(it);
            b1.InnerMethod();
            f1.MyMethod();
            Thread myThread = new Thread(f1.MyMethod);
            myThread.Start();
            Bar2 bar2 = new Bar2(it);
            Thread myThread2 = new Thread(bar2.InnerMethod);
            myThread2.Start();
            myThread.Join();
            myThread2.Join();
            TraceResult tr = it.GetTraceResult();
            XmlSerializator xmlFormatter = new XmlSerializator();
            JsonSerializator jsonFormatter = new JsonSerializator();

            Console.WriteLine("c-console,any symbol-file");
            if (Console.ReadKey().KeyChar=='c')
            {
                ConsoleWriter xmlcw = new ConsoleWriter();
                ConsoleWriter jsoncw = new ConsoleWriter();
                xmlcw.Write(xmlFormatter.Serialize(tr));
                Console.WriteLine();
                jsoncw.Write(jsonFormatter.Serialize(tr));
            }
            else
            {
                Console.WriteLine("FileName for xml:");
                string fName = Console.ReadLine();
                FileWriter xmlfw = new FileWriter(fName+".xml");
                xmlfw.Write(xmlFormatter.Serialize(tr));
                Console.WriteLine("FileName for json:");
                fName = Console.ReadLine();
                FileWriter jsonfw = new FileWriter(fName+".json");
                jsonfw.Write(jsonFormatter.Serialize(tr));
            }
            
            
            
        }
    }

    public class Foo
    {
        private Bar _bar;
        private Bar1 _bar1;
        private ITracer _tracer;

        internal Foo(ITracer tracer)
        {
            _tracer = tracer;
            _bar = new Bar(_tracer);
            _bar1 = new Bar1(_tracer);
        }

        public void MyMethod()
        {
            _tracer.StartTrace();
             _bar.InnerMethod();
             _bar1.InnerMethod();
             _tracer.StopTrace();
        }
    }

    public class Bar
    {
        private ITracer _tracer;

        internal Bar(ITracer tracer)
        {
            _tracer = tracer;
        }

        public void InnerMethod()
        {
         _tracer.StartTrace();
            Thread.Sleep(50);
        _tracer.StopTrace();
        }
    }

    public class Bar1
    {
        private ITracer _tracer;
        private Bar2 _bar2;

        internal Bar1(ITracer tracer)
        {
            _tracer = tracer;
            _bar2 = new Bar2(tracer);
        }

        public void InnerMethod()
        {
            _tracer.StartTrace();
            _bar2.InnerMethod();
            _tracer.StopTrace();
        }
    }

    public class Bar2
    {
        private ITracer _tracer;

        internal Bar2(ITracer tracer)
        {
            _tracer = tracer;
        }

        public void InnerMethod()
        {
            _tracer.StartTrace();
            Thread.Sleep(50);
            _tracer.StopTrace();
        }
    }
}
