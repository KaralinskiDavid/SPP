﻿using System;
using System.Collections.Generic;
using System.Text;
using TracerLib;

namespace ConsoleApp9
{
    abstract class Serializator
    {
        public abstract string Serialize(TraceResult tr);

    }
}
