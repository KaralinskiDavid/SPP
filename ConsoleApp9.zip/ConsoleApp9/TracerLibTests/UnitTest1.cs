using Microsoft.VisualStudio.TestTools.UnitTesting;
using TracerLib;
using System.Threading;
using System.Collections.Generic;

namespace TracerLibTests
{
    [TestClass]
    public class TracerTests
    {
        public Tracer tracer = new Tracer();

        private void MyMethod()
        {
            tracer.StartTrace();
            MyChildMethod();
            Thread.Sleep(20);
            tracer.StopTrace();
        }

        private void MyChildMethod()
        {
            tracer.StartTrace();
            Thread.Sleep(10);
            tracer.StopTrace();
        }

        private void NestingCheckMethod()
        {
            tracer.StartTrace();
            Thread.Sleep(20);
            MyChildWithChildMethod();
            tracer.StopTrace();
        }

        private void MyChildWithChildMethod()
        {
            tracer.StartTrace();
            Thread.Sleep(5);
            ChildsChildMethod();
            tracer.StopTrace();
        }

        private void ChildsChildMethod()
        {
            tracer.StartTrace();
            Thread.Sleep(5);
            tracer.StopTrace();
        }

        [TestMethod]
        public void NestingCheck()
        {
            string methodNameExpected = nameof(ChildsChildMethod);

            NestingCheckMethod();
            TraceResult traceResult = tracer.GetTraceResult();
            string methodNameActual = traceResult.threads[0].methods[0].children[0].children[0].methodName;

            Assert.AreEqual(methodNameExpected,methodNameActual);
        }

        [TestMethod]
        public void MethodCountCheck()
        {
            int methodsExpected = 3;
            int childMethodsExpected = 3;

            for(var i=0;i<3;i++)
            {
                MyMethod();
            }
            TraceResult traceResult = tracer.GetTraceResult();
            int methodsActual = traceResult.threads[0].methods.Count;
            int childMethodsActual=0;
            foreach(MethodResult methodResult in traceResult.threads[0].methods)
            {
                childMethodsActual += methodResult.children.Count;
            }

            Assert.AreEqual(methodsExpected, methodsActual);
            Assert.AreEqual(childMethodsExpected, childMethodsActual);

        }

        [TestMethod]
        public void ThreadExecutionTimeCheck()
        {
            long executionTimeExpected = 30;

            MyMethod();
            TraceResult traceResult = tracer.GetTraceResult();

            long executionTimeActual = traceResult.threads[0].fulltime;

            Assert.AreEqual(executionTimeExpected, executionTimeActual,5);
        }

        [TestMethod]
        public void NamesCheck()
        {
            string methodNameExpected = nameof(NamesCheck);
            string classNameExpected = nameof(TracerTests);
            int threadIdExpected = Thread.CurrentThread.ManagedThreadId;

            tracer.StartTrace();
            tracer.StopTrace();
            TraceResult traceResult = tracer.GetTraceResult();
            string methodNameActual = traceResult.threads[0].methods[0].methodName;
            string classNameActual = traceResult.threads[0].methods[0].className;
            int threadIdActual = traceResult.threads[0].threadId;

            Assert.AreEqual(methodNameExpected, methodNameActual);
            Assert.AreEqual(classNameExpected, classNameActual);
            Assert.AreEqual(threadIdExpected, threadIdActual);

        }

        [TestMethod]
        public void ThreadsCount()
        {
            int threadsCountExpected = 3;

            List<Thread> threadList = new List<Thread>();
            for(var i=0;i<3;i++)
            {
                threadList.Add(new Thread(MyMethod));
            }
            foreach(Thread thread in threadList)
            {
                thread.Start();
                thread.Join();
            }
            TraceResult traceResult = tracer.GetTraceResult();
            int threadsCountActual = traceResult.threads.Count;

            Assert.AreEqual(threadsCountExpected, threadsCountActual);
        }
    }
}
