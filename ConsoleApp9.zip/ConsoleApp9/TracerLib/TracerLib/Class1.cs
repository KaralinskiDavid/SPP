﻿using System;

namespace TracerLib
{
    public class Class1
    {
    }
}
